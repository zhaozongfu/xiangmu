<template>
    <div>
        
    </div>
</template>

<script>
export default {
    name: 'WorkspaceJsonFoot',

    data() {
        return {
            
        };
    },

    mounted() {
        
    },

    methods: {
        
    },
};
</script>

<style lang="scss" scoped>

</style>