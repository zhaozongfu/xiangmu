<template>
    <div>
        这是福利页面
    </div>
</template>

<script>
export default {
    name: 'WorkspaceJsonFLdata',

    data() {
        return {
            
        };
    },

    mounted() {
        
    },

    methods: {
        
    },
};
</script>

<style lang="scss" scoped>

</style>