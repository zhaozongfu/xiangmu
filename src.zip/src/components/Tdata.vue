<template>
    <div>
        这是听书页面
    </div>
</template>

<script>
export default {
    name: 'WorkspaceJsonTdata',

    data() {
        return {
            
        };
    },

    mounted() {
        
    },

    methods: {
        
    },
};
</script>

<style lang="scss" scoped>

</style>