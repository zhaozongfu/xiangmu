<template>
  <div id="box">
    <div v-show="id == 1">
      <search></search>
      <fuli></fuli>
    </div>
    <div v-show="id == 1">
      <search></search>
      <under></under>
      <navigation></navigation>
    </div>
    <div v-show="id == 3">
      <search></search>
      <under></under>
    </div>
    <div class="foot">
      <ul>
        <li v-for="(item, index) in fontsss" :key="index">
          <img :src="item.icon" alt width="30px" height="30px" />
          <p>{{ item.text }}</p>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import search from "./components/Search.vue";
import under from "./components/Under.vue";
import fuli from "./components/foot.vue";
import navigation from "./components/navigation.vue";
export default {
  data() {
    return {
      id: 1,
      color: "#000",
      activeindex: 0,
      components: {
        search,
        under,
        navigation,
        fuli
      },
      fontsss: [
        {
          id: 1,
          icon: "https://img.icons8.com/?size=2x&id=15895&format=png",
          text: "福利"
        },
        {
          id: 2,
          icon: "https://img.icons8.com/?size=2x&id=1767&format=png",
          text: "书城"
        },
        {
          id: 3,
          icon: "https://img.icons8.com/?size=512&id=NMcUI9NdpWhA&format=png",
          text: "听书"
        }
      ],

      methods: {
        activeab(index, id) {
          console.log(id);
          this.id = id;
          this.activeindex = index;
        }
      }
    };
  }
};
</script>

<style>
* {
  margin: 0;
  padding: 0;
  list-style: none;
  text-decoration: none;
}
</style>
<style scoped>
#box {
  width: 100%;
  height: 100vh;
  overflow-y: auto;
  overflow-x: hidden;
  z-index: 0;
}
::-webkit-scrollbar {
  display: none;
}
.foot {
  position: fixed;
  bottom: 0;
  width: 100%;
  height: 55px;
  z-index: 1 !important;
  background-color: #fff;
}

.foot ul li {
  display: inline-block;
}

.foot ul {
  width: 100%;
  display: flex;
  justify-content: space-around;
}
.foot ul li:nth-child(2) {
  color: aqua;
}
.foot ul li img:nth-child(2) {
  background-color: aqua;
}
.active {
  color: aqua;
}
</style>
