<template>
    <div class="navigation">
        <ul class="ull">
            <li v-for="(item, index) in list" :key="index">
                {{ item.line }}
            </li>
        </ul>
    </div>
</template>

<script>
export default {
    name: 'WorkspaceJsonNavigation',

    data() {
        return {
            list: [
                {
                    line: "推荐"
                },
                {
                    line: "分类"
                },
                {
                    line: "排行"
                },
                {
                    line: "文学艺术"
                },
                {
                    line: "哲学社科"
                }
            ],
        };
    },

    mounted() {

    },

    methods: {

    },
};
</script>

<style scoped>
.navigation {
    position: sticky;
    top:110px;
    z-index: 1;
    width: 100%;
    height: 80px;
}

.ull {
    width: 100%;
    height: 55px;
    line-height: 50px;
    display: flex;
    justify-content: space-around;
    background-color: white;
}

.ull li {
    display: inline-block;
    font-size: 18px;
    color: #56585f;
}
</style>