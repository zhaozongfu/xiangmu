<template>
  <div id="box">
    <search></search><!-- 顶部 -->
    <under></under><!-- 记录部分 -->
    <navigation></navigation><!-- 上面导航 -->
    <fooder></fooder><!-- 内容主题 -->
    <foot></foot><!-- 底部导航 -->
  </div>
</template>
<script>
import search from '../components/Search.vue'
import under from '../components/Under.vue'
import fooder from '../components/fooder.vue'
import foot from '../components/foot.vue'
import navigation from '../components/navigation.vue'
export default {
  components: {
    search,
    under,
    fooder,
    foot,
    navigation,
  },
 
}
</script>
<style scoped>
  #box{
    width: 100%;
    height: 100vh;
    overflow-y: auto;
    overflow-x: hidden;
  }
</style>







