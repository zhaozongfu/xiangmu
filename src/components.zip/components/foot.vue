<template>
    <div class="foot">
        <ul>
            <li v-for="(item, index) in fonts" :key="index">
                <img :src="item.icon" alt="" width="30px" height="30px">
            </li>
        </ul>
    </div>
</template>

<script>
export default {
    name: 'WorkspaceJsonFoot',

    data() {
        return {
            fonts: [
                {
                    icon: "https://img.icons8.com/?size=2x&id=15895&format=png"
                }
            ]
        };
    },

    mounted() {

    },

    methods: {

    },
};
</script>

<style scoped>
.foot {
    position: fixed;
    bottom: 0;
    width: 100%;
    height: 60px;
    background-color: chocolate;
}
</style>