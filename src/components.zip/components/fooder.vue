<template>
    <div class="fooder">
        
        <div class="text" v-for="(item, index) in shuzu" :key="index">
            <span class="html1">
                <img :src="item.img" alt="" width="80px" height="92px">
                <span>{{ item.name }}</span>
                <p>{{ item.zuozhe }}</p>
                <p>{{ item.wocaole }}</p>
                <img id="image" :src="item.image" width="40px" height="15px">
            </span>
        </div>
    </div>
</template>

<script>
export default {
    name: 'WorkspaceJsonFooder',
    data() {
        return {
            list: [
                {
                    line: "推荐"
                },
                {
                    line: "分类"
                },
                {
                    line: "排行"
                },
                {
                    line: "文学艺术"
                },
                {
                    line: "哲学社科"
                }
            ],
            shuzu: [
                {
                    name: "夜盲",
                    zuozhe: "理查德发 | 推荐值99%",
                    img: 'https://hbimg.b0.upaiyun.com/9af394d9bb22e56c741fb60c3561a510d256d16e211d0-UdqlXt_fw658',
                    wocaole: '大家都在读',
                    image: "https://weread-1258476243.file.myqcloud.com/miniprogram/assets/reader/newRatings_900.png"
                },
                {
                    name: "我与阿长",
                    zuozhe: "干饭人 | 推荐值80%",
                    img: 'https://hbimg.b0.upaiyun.com/2d76fd4982f35a676d3996947f20682c02b6e4b8ab8c9-djFsy8_fw658',
                    wocaole: '大家都在读',
                    image: "https://weread-1258476243.file.myqcloud.com/miniprogram/assets/reader/newRatings_870.png"
                },
                {
                    name: "说红楼",
                    zuozhe: "一条鱼 | 推荐值90%",
                    img: 'http://t14.baidu.com/it/u=2352542786,123467867&fm=224&app=112&f=JPEG?w=500&h=500',
                    wocaole: '大家都在读',
                    image: "https://weread-1258476243.file.myqcloud.com/miniprogram/assets/reader/newRatings_800.png"
                },
                {
                    name: "壁江山",
                    zuozhe: "泡泡彤 | 推荐值99%",
                    img: 'https://hbimg.b0.upaiyun.com/08119561e591850fd25316a3e2c4a87193dcd38669a83-6J67Fa_fw658',
                    wocaole: '大家都在读',
                    image: "https://weread-1258476243.file.myqcloud.com/miniprogram/assets/reader/newRatings_900.png"
                },
                {
                    name: "筑梦师",
                    zuozhe: "汰哆 | 推荐值80%",
                    img: 'https://hbimg.b0.upaiyun.com/505cdcac3f6654b055347955f8977078ab4816485ff31-gOEz2U_fw658',
                    wocaole: '大家都在读',
                    image: "https://weread-1258476243.file.myqcloud.com/miniprogram/assets/reader/newRatings_800.png"
                },
                {
                    name: "长江岔",
                    zuozhe: "多好多好 | 推荐值99%",
                    img: 'https://ss3.baidu.com/9fo3dSag_xI4khGko9WTAnF6hhy/zhidao/pic/item/a8014c086e061d9540bfd04f7ff40ad163d9cac8.jpg',
                    wocaole: '大家都在读',
                    image: "https://weread-1258476243.file.myqcloud.com/miniprogram/assets/reader/newRatings_900.png"
                },
                {
                    name: "苍蓝色的讨伐者",
                    zuozhe: "为你写诗 | 推荐值85%",
                    img: 'https://www.mx-fm.com/upfile/201512/2015122978601809.jpg',
                    wocaole: '大家都在读',
                    image: "https://weread-1258476243.file.myqcloud.com/miniprogram/assets/reader/newRatings_900.png"
                },
            ]
        }
    }
};
</script>

<style scoped>
.fooder {
    width: 100%;
    height: 100%;
    margin-bottom: 80px;
}


.text {
    position: relative;
    top: -15px;
    width: 100%;
    height: auto;
}

.text .html1 {
    display: block;
    width: 100%;
    height: 92px;
    margin-top: 0.5rem;
}

.html1 img {
    position: relative;
    left: 18px;
}

.html1 span {
    position: relative;
    top: -50px;
    left: 32px;
    font-size: 20px;
}

.html1 p {
    position: relative;
    top: -48px;
    left: 112px;
    font-size: 12px;
    color: gray;

}

#image {
    position: relative;
    top: -78px;
    left: -100px;
    float: right;
}
</style>